export const set = () => true;
export const get = () => true;
export const length = () => true;
export { remove as delete };
const remove = () => true;