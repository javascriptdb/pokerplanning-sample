let t;function n(i){t=i.client}export{t as c,n as i};
